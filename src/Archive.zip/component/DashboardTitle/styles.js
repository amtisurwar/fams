import * as Common from '../../common/common';

export default {
  textStyle: {
    color: Common.blackColor,
    padding: 5,
    alignSelf: 'center'
  }
};
