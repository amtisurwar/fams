import { StyleSheet } from 'react-native';
import * as Common from '../../common/common';

const styles = StyleSheet.create({
  headerContainer: {
    backgroundColor: Common.lightGreen,
  },
  question: {
    fontSize: 20,
  },
  ratingView: {
    
  }
});

module.exports = styles;
